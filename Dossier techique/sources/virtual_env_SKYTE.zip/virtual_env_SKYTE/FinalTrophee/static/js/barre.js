const endpoint = 'https://raw.githubusercontent.com/galaxochy/tropheenis/main/data.json';

const cities = [];
fetch(endpoint)
  .then(blob => blob.json())
  .then(data => cities.push(...data));

  function findMatches(input_user, cities) {
    // filters the cities in our array in terms of the input of user
    return cities.filter(place => {
        //  create a regular expression  with the input of the user and the 'gi' flag which stands for global search and case-insensitive search
      const regex = new RegExp(input_user, 'gi');
      //  city or state matches what was searched so, the regular expression above
      return place.Ville.match(regex) 
    });
  }
  
  function displayMatches() {
    const matchArray = findMatches(this.value, cities);
      // Limit the number of matches to display to 5
    const limitedMatches = matchArray.slice(0, 5);
    // Generate HTML for each match
    const html = limitedMatches.map(place => {
      const regex = new RegExp(this.value, 'gi');
      const cityName = place.Ville.replace(regex, `<span class="hl">${this.value}</span>`);
      const dpt = place.dpt 
      const code = place.code
      
      return `

      <a href="/spots/${code}">
      <li>
          <span class="nom-de-ville">${cityName}, ${dpt} </span>
          </li>
      </a>
      `;
    }).join('');
    suggestions.innerHTML = html;
  }
  
  const searchInput = document.querySelector('.barre');
  const suggestions = document.querySelector('.suggestions');
  
  searchInput.addEventListener('change', displayMatches);
  searchInput.addEventListener('keyup', displayMatches);
