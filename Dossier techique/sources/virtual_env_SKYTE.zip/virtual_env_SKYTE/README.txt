Prérequis:
- ordinateur windows
- vscode
- ecran FHD (si possible, pour eviter les bugs d'affichages)

ouvrir le dossier Virtual_env_SKYTE avec vscode

Le projet se trouve dans un environnement virtuel,
pour lancer l'environnement virtuel, il suffit de taper dans le terminal du dossier:

>>venv\Scripts\activate

Une petite icône (env) devrait normalement apparaître à côté du chemin du fichier:

>>(env) C:\user\Desktop\Virtual_env_SKYTE

Ensuite naviguez jusqu'au dossier FinalTrophee avec la commande:

>>cd FinalTrophee

Puis lancez le script main.py avec la commande:

>>python main.py

L'application flask se lance et vous n'avez plus qu'a accéder au lien qui apparait dans le terminal




Après l utilisation, appuyez sur ctrl+c dans le terminal de main.py pour terminer l’application flask.

Entrez la commande suivante pour désactiver l'environnement virtuel:

>>deactivate


Si l'application ne se lance pas ou que vous rencontrez des problemes veuillez regarder à la fin de la documentation.

Compte de test:
mail: compte@gmail.com
mot de passe: compte